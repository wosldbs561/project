package com.mall.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class StatChartDTO {

	private String categoryname;
	private int	orderprice;
}
