package com.mall.domain;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class CategoryVO {
	
	private Integer cat_code;
	private int	cat_prtcode;
	private String cat_name;
}
